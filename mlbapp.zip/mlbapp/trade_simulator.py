#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Trade Simulator Module
Uses 2026_player_projections.csv to swap players and recalc standings.
"""

import os
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

BASE_DIR = os.path.expanduser("~/Desktop/mlbapp")

# --- Load historical finance/performance data ---
finance_csv = os.path.join(BASE_DIR, "mlb_finance_data_1.csv")
df = pd.read_csv(finance_csv)

df.rename(columns={"Team Total WAR": "WAR"}, inplace=True)
win_col = [c for c in df.columns if "Win" in c or "Pct" in c][0]
if df[win_col].max() > 1.0:
    df[win_col] = df[win_col] / 100.0
if "Season" in df.columns:
    df = df[df["Season"] != 2020]

war_model = LinearRegression()
war_model.fit(df[["WAR"]], df[win_col])

# --- Load projected team WAR data ---
proj_csv = os.path.join(BASE_DIR, "projected_mlb_team_data.csv")
proj_df = pd.read_csv(proj_csv)

if "WAR" not in proj_df.columns:
    if "projected_war" in proj_df.columns:
        proj_df.rename(columns={"projected_war": "WAR"}, inplace=True)
    elif "Projected WAR" in proj_df.columns:
        proj_df.rename(columns={"Projected WAR": "WAR"}, inplace=True)
proj_df["WAR"] = pd.to_numeric(proj_df["WAR"], errors="coerce").fillna(0)

# --- Add league/division mapping ---
team_divisions = {
    "Yankees":("AL","East"),"Red Sox":("AL","East"),"Blue Jays":("AL","East"),
    "Rays":("AL","East"),"Orioles":("AL","East"),
    "Guardians":("AL","Central"),"White Sox":("AL","Central"),"Tigers":("AL","Central"),
    "Royals":("AL","Central"),"Twins":("AL","Central"),
    "Astros":("AL","West"),"Mariners":("AL","West"),"Rangers":("AL","West"),
    "Athletics":("AL","West"),"Angels":("AL","West"),
    "Braves":("NL","East"),"Mets":("NL","East"),"Phillies":("NL","East"),
    "Nationals":("NL","East"),"Marlins":("NL","East"),
    "Cubs":("NL","Central"),"Cardinals":("NL","Central"),"Brewers":("NL","Central"),
    "Pirates":("NL","Central"),"Reds":("NL","Central"),
    "Dodgers":("NL","West"),"Giants":("NL","West"),"Padres":("NL","West"),
    "Rockies":("NL","West"),"Diamondbacks":("NL","West"),
}
proj_df["league"] = proj_df["Team"].map(lambda t: team_divisions.get(t,("Unknown","Unknown"))[0])
proj_df["division"] = proj_df["Team"].map(lambda t: team_divisions.get(t,("Unknown","Unknown"))[1])

# --- Load player projections ---
players_csv = os.path.join(BASE_DIR, "2026_player_projections.csv")
players_df = pd.read_csv(players_csv)

players_df.rename(columns={
    "Name": "Player",
    "Projected_WAR": "WAR",
    "projected_war": "WAR"
}, inplace=True)

players_df["WAR"] = pd.to_numeric(players_df["WAR"], errors="coerce").fillna(0)
players_df["Player"] = players_df["Player"].str.strip().str.lower()

# Map team abbreviations to full names
team_name_map = {
    "NYY": "Yankees", "BOS": "Red Sox", "TOR": "Blue Jays", "TB": "Rays", "BAL": "Orioles",
    "CLE": "Guardians", "CWS": "White Sox", "DET": "Tigers", "KC": "Royals", "MIN": "Twins",
    "HOU": "Astros", "SEA": "Mariners", "TEX": "Rangers", "OAK": "Athletics", "LAA": "Angels",
    "ATL": "Braves", "NYM": "Mets", "PHI": "Phillies", "WSH": "Nationals", "MIA": "Marlins",
    "CHC": "Cubs", "STL": "Cardinals", "MIL": "Brewers", "PIT": "Pirates", "CIN": "Reds",
    "LAD": "Dodgers", "SF": "Giants", "SD": "Padres", "COL": "Rockies", "ARI": "Diamondbacks"
}
players_df["Team"] = players_df["Team"].map(lambda abbr: team_name_map.get(abbr, abbr))

# --- Recalculate Standings ---
def recalc_standings():
    proj_df["win_pct"] = war_model.predict(proj_df[["WAR"]])
    proj_df["wins"] = (proj_df["win_pct"] * 162).round().astype(int)
    proj_df["losses"] = 162 - proj_df["wins"]
    return proj_df

# --- Trade Function ---
def execute_trade(player_a, player_b):
    try:
        row_a = players_df.loc[players_df["Player"] == player_a].iloc[0]
        row_b = players_df.loc[players_df["Player"] == player_b].iloc[0]
    except IndexError:
        print("\nError: One or both player names not found.")
        return False

    team_a, war_a = row_a["Team"], row_a["WAR"]
    team_b, war_b = row_b["Team"], row_b["WAR"]

    if team_a not in proj_df["Team"].values or team_b not in proj_df["Team"].values:
        print(f"\nError: One or both teams not found in projected data. ({team_a}, {team_b})")
        return False

    # --- Capture BEFORE values ---
    before = recalc_standings()
    before_a = before.loc[before["Team"] == team_a].copy()
    before_b = before.loc[before["Team"] == team_b].copy()

    # Execute trade
    proj_df.loc[proj_df["Team"] == team_a, "WAR"] += war_b - war_a
    proj_df.loc[proj_df["Team"] == team_b, "WAR"] += war_a - war_b

    # --- Capture AFTER values ---
    after = recalc_standings()
    after_a = after.loc[after["Team"] == team_a].copy()
    after_b = after.loc[after["Team"] == team_b].copy()

    print(f"\nTrade executed: {player_a.title()} ({team_a}, WAR {war_a}) ↔ {player_b.title()} ({team_b}, WAR {war_b})")

    # --- Show Before vs After ---
    def show_effects(team, before, after):
        print(f"\n{team} Before → After")
        print(f"WAR: {before['WAR'].values[0]:.2f} → {after['WAR'].values[0]:.2f}")
        print(f"Wins: {before['wins'].values[0]} → {after['wins'].values[0]}")
        print(f"Losses: {before['losses'].values[0]} → {after['losses'].values[0]}")
        print(f"Win%: {before['win_pct'].values[0]:.3f} → {after['win_pct'].values[0]:.3f}")

    show_effects(team_a, before_a, after_a)
    show_effects(team_b, before_b, after_b)

    # --- Decide Winner ---
    delta_a = after_a["wins"].values[0] - before_a["wins"].values[0]
    delta_b = after_b["wins"].values[0] - before_b["wins"].values[0]

    if delta_a > delta_b:
        print(f"\n🏆 Winner of the trade: {team_a} (+{delta_a} wins)")
    elif delta_b > delta_a:
        print(f"\n🏆 Winner of the trade: {team_b} (+{delta_b} wins)")
    else:
        print("\n🤝 The trade is balanced — no clear winner.")

    return True

# --- Public entry point for the app ---
def run_trade_simulator():
    print("Trade Simulator")
    print("\nAvailable players (first 20 shown):")
    preview = players_df[["Player", "Team", "WAR"]].head(20)
    print(preview.to_string(index=False))

    player_a = input("\nEnter first player to trade: ").strip().lower()
    player_b = input("Enter second player to trade: ").strip().lower()

    if execute_trade(player_a, player_b):
        updated = recalc_standings()
        print("\nUpdated Standings:")
        for lg in ["AL", "NL"]:
            for div in ["East", "Central", "West"]:
                block = updated[(updated["league"] == lg) & (updated["division"] == div)]
                print(f"\n{lg} {div}")
                for _, r in block.iterrows():
                    print(f" - {r['Team']}: {r['wins']}-{r['losses']} ({r['win_pct']:.3f})")
