#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Current MLB Player Stuff+ Calculator
Evaluates Stuff+ for all pitch types thrown by a given pitcher,
using league-wide pitch-type averages as baselines.
Author: Chris Jones
"""

from pybaseball import statcast, statcast_pitcher, playerid_lookup, cache
import pandas as pd

# Enable caching so Statcast queries don’t re-download every time
cache.enable()

# --- Pitch-type specific weights (from your regression results) ---
PITCH_TYPE_WEIGHTS = {
    "FF": {"velocity": 0.1919, "spin": 0.0899, "ivb": 0.0738, "hvb": -0.0037},
    "SI": {"velocity": 0.1617, "spin": 0.0285, "ivb": -0.0264, "hvb": 0.1161},
    "FC": {"velocity": 0.0215, "spin": 0.0443, "ivb": -0.0295, "hvb": 0.1156},
    "SL": {"velocity": 0.0520, "spin": 0.0787, "ivb": -0.0185, "hvb": -0.0207},
    "ST": {"velocity": 0.1581, "spin": 0.0114, "ivb": 0.0532, "hvb": -0.0110},
    "CU": {"velocity": 0.1478, "spin": 0.1273, "ivb": 0.0743, "hvb": 0.0325},
    "KC": {"velocity": 0.2512, "spin": 0.0004, "ivb": 0.0459, "hvb": -0.0508},
    "CH": {"velocity": -0.0469, "spin": 0.0256, "ivb": -0.0180, "hvb": -0.0538},
    "FS": {"velocity": -0.0852, "spin": -0.0762, "ivb": -0.0150, "hvb": -0.0423}
}

# --- Map pitch codes to full names ---
PITCH_NAME_MAP = {
    "FF": "Four-Seam Fastball",
    "SI": "Sinker / Two-Seam",
    "FC": "Cutter",
    "SL": "Slider",
    "ST": "Sweeper",
    "CU": "Curveball",
    "KC": "Knuckle Curve",
    "CH": "Changeup",
    "FS": "Splitter",
    "TOTAL": "Total Stuff+"
}

def calculate_stuff_plus(pitch_code, velocity, spin, ivb, hvb, league_avgs):
    """Calculate Stuff+ for a given pitch using league-wide pitch-type averages."""
    if not isinstance(pitch_code, str):
        return None
    pitch_code = pitch_code.upper()
    if pitch_code not in PITCH_TYPE_WEIGHTS:
        return None

    weights = PITCH_TYPE_WEIGHTS[pitch_code]
    avg = league_avgs.get(pitch_code)
    if avg is None:
        return None

    score = 100
    score += weights["velocity"] * (velocity - avg['release_speed'])
    score += weights["spin"] * (spin - avg['release_spin_rate'])
    score += weights["ivb"] * (ivb - avg['ivb'])
    score += weights["hvb"] * (hvb - avg['hvb'])
    return round(score, 1)

def compute_league_avgs(season=2025):
    """Compute league-wide averages per pitch type for the given season."""
    print("Gathering league-wide data (this may take a while)...")
    league_df = statcast(start_dt=f"{season}-04-01", end_dt=f"{season}-09-30")

    league_df['horiz_adj'] = league_df.apply(
        lambda row: row['pfx_x'] * (-1 if row['p_throws'] == 'L' else 1), axis=1
    )
    league_df['ivb'] = league_df['pfx_z'] + 32 * (league_df['release_extension'] / league_df['release_speed'])
    league_df['hvb'] = league_df['horiz_adj']

    league_avgs = league_df.groupby('pitch_type').agg({
        'release_speed':'mean',
        'release_spin_rate':'mean',
        'ivb':'mean',
        'hvb':'mean'
    }).to_dict('index')

    return league_avgs

def get_player_stuff_plus(player_name, season=2025, league_avgs=None):
    print(f"Gathering Player Data for {player_name}...")

    # Look up player ID
    lookup = playerid_lookup(last=player_name.split()[-1], first=player_name.split()[0])
    if lookup.empty:
        raise ValueError(f"Player {player_name} not found.")
    player_id = int(lookup['key_mlbam'].values[0])

    # Get player-specific Statcast data
    df = statcast_pitcher(start_dt=f"{season}-04-01", end_dt=f"{season}-09-30", player_id=player_id)
    if df.empty:
        raise ValueError(f"No Statcast data found for {player_name} in {season}.")

    # Add IVB/HVB
    df['horiz_adj'] = df.apply(
        lambda row: row['pfx_x'] * (-1 if row['p_throws'] == 'L' else 1), axis=1
    )
    df['ivb'] = df['pfx_z'] + 32 * (df['release_extension'] / df['release_speed'])
    df['hvb'] = df['horiz_adj']

    # Calculate Stuff+ for each pitch
    df['stuff_plus'] = df.apply(
        lambda row: calculate_stuff_plus(
            row['pitch_type'],
            row['release_speed'],
            row['release_spin_rate'],
            row['ivb'],
            row['hvb'],
            league_avgs
        ),
        axis=1
    )

    # Aggregate by pitch type
    summary = df.groupby('pitch_type')['stuff_plus'].mean().round(1).dropna()

    # --- Add Total Stuff+ (weighted by pitch usage) ---
    pitch_counts = df['pitch_type'].value_counts()
    weighted_total = (
        (summary * pitch_counts.loc[summary.index]).sum() / pitch_counts.loc[summary.index].sum()
    ).round(1)
    summary.loc['TOTAL'] = weighted_total

    # Map codes to full names
    summary.index = [PITCH_NAME_MAP.get(code, code) for code in summary.index]

    return summary

def run_player_stuff_plus():
    """Interactive runner for standalone use"""
    print("Player Arsenal Stuff+ Calculator")
    player_name = input("Enter player name (e.g. Gerrit Cole): ").strip()
    season = input("Enter season year (default 2025): ").strip()
    if not season:
        season = 2025
    else:
        season = int(season)

    try:
        league_avgs = compute_league_avgs(season)
        summary = get_player_stuff_plus(player_name, season, league_avgs)
        print(f"\nStuff+ results for {player_name} ({season}):")
        print(summary.to_string())
    except Exception as e:
        print(e)

# --- Wrapper for app launcher ---
def run_current_player_stuff_plus():
    """Entry point for the app launcher"""
    run_player_stuff_plus()

if __name__ == "__main__":
    run_player_stuff_plus()


