#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 27 12:56:37 2025

@author: chrisjones
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stuff+ Calculator Module
Evaluates pitch quality relative to league average, pitch-type specific.
"""

# League averages (example values)
LEAGUE_AVG = {
    "velocity": 93.0,   # mph
    "spin": 2300.0,     # rpm
    "vert_move": 15.0,  # inches
    "horiz_move": 8.0   # inches
}

# Pitch-type specific weights (illustrative regression coefficients)
PITCH_TYPE_WEIGHTS = {
    "fastball": {"velocity": 2.5, "spin": 0.01, "vert_move": 1.8, "horiz_move": 0.5},
    "two_seam": {"velocity": 2.2, "spin": 0.012,"vert_move": 1.0, "horiz_move": 2.2},
    "sinker":   {"velocity": 2.0, "spin": 0.01, "vert_move": 0.5, "horiz_move": 2.0},
    "cutter":   {"velocity": 2.0, "spin": 0.015,"vert_move": 1.0, "horiz_move": 1.5},
    "slider":   {"velocity": 1.0, "spin": 0.02, "vert_move": 0.8, "horiz_move": 2.5},
    "curve":    {"velocity": 0.5, "spin": 0.03, "vert_move": 2.5, "horiz_move": 1.0},
    "changeup": {"velocity": 1.2, "spin": 0.01, "vert_move": 1.5, "horiz_move": 1.5},
    "splitter": {"velocity": 1.5, "spin": 0.005,"vert_move": 2.0, "horiz_move": 1.0}
}

def calculate_stuff_plus(pitch_type, velocity, spin, vert_move, horiz_move):
    pitch_type = pitch_type.lower()
    if pitch_type not in PITCH_TYPE_WEIGHTS:
        raise ValueError(f"Unsupported pitch type: {pitch_type}")

    weights = PITCH_TYPE_WEIGHTS[pitch_type]

    score = 100
    score += weights["velocity"] * (velocity - LEAGUE_AVG["velocity"])
    score += weights["spin"] * (spin - LEAGUE_AVG["spin"])
    score += weights["vert_move"] * (vert_move - LEAGUE_AVG["vert_move"])
    score += weights["horiz_move"] * (horiz_move - LEAGUE_AVG["horiz_move"])
    return round(score, 1)

def run_stuff_plus_calculator():
    print("Stuff+ Calculator")
    print("Supported pitch types:", ", ".join(PITCH_TYPE_WEIGHTS.keys()))

    try:
        pitch_type = input("Enter pitch type: ").strip().lower()
        velocity = float(input("Enter pitch velocity (mph): "))
        spin = float(input("Enter spin rate (rpm): "))
        vert_move = float(input("Enter vertical movement (inches): "))
        horiz_move = float(input("Enter horizontal movement (inches): "))
    except Exception:
        print("Invalid input. Using defaults.")
        pitch_type = "fastball"
        velocity, spin, vert_move, horiz_move = 93.0, 2300.0, 15.0, 8.0
    try:
        stuff_plus = calculate_stuff_plus(pitch_type, velocity, spin, vert_move, horiz_move)
        print(f"\nCalculated Stuff+ for {pitch_type.replace('_',' ').title()}: {stuff_plus} (100 = league average)")
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    run_stuff_plus_calculator()
