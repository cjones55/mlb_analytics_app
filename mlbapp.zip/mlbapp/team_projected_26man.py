#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Team Projected 26-Man Roster + Free Agent Recommendations
Adapts to 2026_freeagents.csv columns (Proj WAR, Med AAV, Med Total)
"""

import pandas as pd
import os

DESKTOP_DIR = os.path.expanduser("~/Desktop")
BASE_DIR = os.path.join(DESKTOP_DIR, "mlbapp")
HITTERS_CSV = os.path.join(BASE_DIR, "2026_player_projections.csv")
PITCHERS_CSV = os.path.join(BASE_DIR, "2026_pitcher_projections.csv")
FA_CSV = os.path.join(BASE_DIR, "2026_freeagents.csv")

TEAM_MAP = {
    "diamondbacks": "ARI","braves": "ATL","orioles": "BAL","red sox": "BOS",
    "cubs": "CHC","white sox": "CHW","reds": "CIN","guardians": "CLE",
    "rockies": "COL","tigers": "DET","astros": "HOU","royals": "KCR",
    "angels": "LAA","dodgers": "LAD","marlins": "MIA","brewers": "MIL",
    "twins": "MIN","mets": "NYM","yankees": "NYY","athletics": "OAK",
    "phillies": "PHI","pirates": "PIT","padres": "SDP","giants": "SFG",
    "mariners": "SEA","cardinals": "STL","rays": "TBR","rangers": "TEX",
    "blue jays": "TOR","nationals": "WSN"
}

def normalize_pos(pos):
    p = str(pos).upper()
    if p in ["OF","OUTFIELD"]: return "OF"
    if p in ["SP","STARTER"]: return "SP"
    if p in ["RP","RELIEVER","RELIEF"]: return "RP"
    return p

def run_team_roster_with_fa(team_name):
    # Load data
    hitters = pd.read_csv(HITTERS_CSV)
    pitchers = pd.read_csv(PITCHERS_CSV)
    free_agents = pd.read_csv(FA_CSV)

    if "Pos" in free_agents.columns:
        free_agents["Pos"] = free_agents["Pos"].apply(normalize_pos)

    team_code = TEAM_MAP.get(team_name.strip().lower(), team_name.upper())
    hitters_team = hitters[hitters["Team"].fillna("").str.upper() == team_code]
    pitchers_team = pitchers[pitchers["Team"].fillna("").str.upper() == team_code]

    # === Build roster ===
    lineup = hitters_team.sort_values("PA", ascending=False).head(9)
    bench = hitters_team.sort_values("PA", ascending=False).iloc[9:13]
    rotation = pitchers_team.sort_values("WAR", ascending=False).head(5)
    bullpen = pitchers_team.sort_values("WAR", ascending=False).iloc[5:13]

    print(f"\n=== Projected 26-Man Roster: {team_code} ({team_name.title()}) ===")

    # Starting lineup
    print("\n-- Starting Lineup --")
    for _, row in lineup.iterrows():
        print(f"{row['Name']:<20} | PA: {row['PA']} "
              f"| OBP: {row.get('OBP','N/A')} | HR: {row.get('HR','N/A')} | WAR: {row.get('WAR','N/A')}")

    # Bench
    print("\n-- Bench --")
    for _, row in bench.iterrows():
        print(f"{row['Name']:<20} | PA: {row['PA']} "
              f"| OBP: {row.get('OBP','N/A')} | WAR: {row.get('WAR','N/A')}")

    # Rotation
    print("\n-- Rotation --")
    for _, row in rotation.iterrows():
        print(f"{row['Name']:<20} | WAR: {row.get('WAR','N/A')} | IP: {row.get('IP','N/A')}")

    # Bullpen
    print("\n-- Bullpen --")
    for _, row in bullpen.iterrows():
        print(f"{row['Name']:<20} | WAR: {row.get('WAR','N/A')} | IP: {row.get('IP','N/A')}")

    # === Suggested Improvements ===
    weakest_hitter = lineup.sort_values("OBP").iloc[0] if "OBP" in lineup.columns else None
    weakest_sp = rotation.sort_values("WAR").iloc[-1] if "WAR" in rotation.columns else None

    if weakest_hitter is not None or weakest_sp is not None:
        print(f"\n-- Suggested Improvements --")
    if weakest_hitter is not None:
        print(f"Lineup: Upgrade OBP at {weakest_hitter['Name']} (OBP {weakest_hitter['OBP']})")
    if weakest_sp is not None:
        print(f"Rotation: Upgrade back-end starter {weakest_sp['Name']} (WAR {weakest_sp['WAR']})")

    # === Free Agent Recommendations ===
    print(f"\n=== Free Agent Recommendations for {team_code} ({team_name.title()}) ===")
    current_names = set(pd.concat([lineup, bench, rotation, bullpen])["Name"].tolist())

    # Hitters
    if weakest_hitter is not None:
        print(f"\n-- Upgrade hitter: {weakest_hitter['Name']} --")
        fa_hitters = free_agents[free_agents["Pos"].isin(["C","1B","2B","3B","SS","LF","CF","RF","DH","OF"])]
        fa_hitters = fa_hitters[~fa_hitters["Name"].isin(current_names)]
        sort_col = None; asc = False
        if "Proj WAR" in fa_hitters.columns:
            sort_col = "Proj WAR"; asc = False
        elif "Med AAV" in fa_hitters.columns:
            sort_col = "Med AAV"; asc = True
        elif "Med Total" in fa_hitters.columns:
            sort_col = "Med Total"; asc = True
        if sort_col and not fa_hitters.empty:
            fa_hitters = fa_hitters.sort_values(sort_col, ascending=asc).head(5)
            for _, row in fa_hitters.iterrows():
                print(f"{row['Name']:<20} | Pos: {row.get('Pos','N/A')} | {sort_col}: {row.get(sort_col,'N/A')}")
        else:
            print("No suitable hitter candidates found.")

    # Pitchers
    if weakest_sp is not None:
        print(f"\n-- Upgrade rotation: {weakest_sp['Name']} --")
        fa_pitchers = free_agents[free_agents["Pos"].isin(["SP","RP"])]
        fa_pitchers = fa_pitchers[~fa_pitchers["Name"].isin(current_names)]
        sort_col = None; asc = False
        if "Proj WAR" in fa_pitchers.columns:
            sort_col = "Proj WAR"; asc = False
        elif "Med AAV" in fa_pitchers.columns:
            sort_col = "Med AAV"; asc = True
        elif "Med Total" in fa_pitchers.columns:
            sort_col = "Med Total"; asc = True
        if sort_col and not fa_pitchers.empty:
            fa_pitchers = fa_pitchers.sort_values(sort_col, ascending=asc).head(5)
            for _, row in fa_pitchers.iterrows():
                print(f"{row['Name']:<20} | Pos: {row.get('Pos','N/A')} | {sort_col}: {row.get(sort_col,'N/A')}")
        else:
            print("No suitable pitcher candidates found.")

if __name__ == "__main__":
    team_name = input("Enter team name: ")
    run_team_roster_with_fa(team_name)



