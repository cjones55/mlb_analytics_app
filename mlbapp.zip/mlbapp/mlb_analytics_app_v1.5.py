#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MLB Analytics App Launcher
"""
import subprocess
import os
import sys

# Always point to mlbapp folder on Desktop
DESKTOP_DIR = os.path.expanduser("~/Desktop")
BASE_DIR = os.path.join(DESKTOP_DIR, "mlbapp")
sys.path.append(BASE_DIR)  # ensure imports work

# Direct imports for callable modules
import trade_simulator
import stuff_plus_calculator          # basic manual calculator
import current_player_stuff_plus      # Statcast-based player Stuff+
import team_projected_26man

def main():
    print("MLB Analytics App by Chris Jones v1.5")
    print("1. League/Team Projections")
    print("2. Front Office Tools")
    print("3. Pitcher Stuff+ Evaluation")
    print("4. Model Creation")

    choice = input("Select section (1–4): ").strip()

    if choice == "1":
        run_league_team_menu()
    elif choice == "2":
        run_front_office_menu()
    elif choice == "3":
        run_pitcher_menu()
    elif choice == "4":
        run_model_menu()
    else:
        print("Invalid choice. Please run again.")

# -------------------------------
# Section 1: League/Team Analytics
# -------------------------------
def run_league_team_menu():
    print("\nLeague/Team Projections")
    print("a. Run full standings projections")
    print("b. Run Team Projected 26-Man Roster + FA Recommendations")
    sub_choice = input("Select option (a–b): ").strip().lower()

    if sub_choice == "a":
        proj_csv = os.path.join(BASE_DIR, "projected_mlb_team_data.csv")
        finance_csv = os.path.join(BASE_DIR, "mlb_finance_data_1.csv")
        save_choice = input("Save grouped standings CSV to mlbapp folder? (y/n): ").strip().lower()
        cmd = [
            "python", os.path.join(BASE_DIR, "standings_projections.py"),
            "--csv", proj_csv,
            "--finance_csv", finance_csv
        ]
        if save_choice == "y":
            cmd.append("--save")
        subprocess.run(cmd)

    elif sub_choice == "b":
        team_name = input("Enter team name: ").strip()
        team_projected_26man.run_team_roster_with_fa(team_name)

# -------------------------------
# Section 2: Front Office Tools
# -------------------------------
def run_front_office_menu():
    print("\nFront Office Tools")
    print("a. Team projected evaluation via WAR + cost of WAR")
    print("b. Add free agent to team projections")
    print("c. Run Trade Simulator")
    sub_choice = input("Select option (a–c): ").strip().lower()

    if sub_choice == "a":
        try:
            payroll = float(input("Enter team payroll in dollars: "))
            war = float(input("Enter projected team WAR: "))
        except Exception:
            print("Invalid input. Using defaults.")
            payroll, war = 120_000_000, 35.0

        subprocess.run([
            "python", os.path.join(BASE_DIR, "single_team_simulator.py"),
            "--payroll", str(payroll),
            "--war", str(war)
        ])

    elif sub_choice == "b":
        team_name = input("Which team is adding the free agent? ").strip()
        player_name = input("Which free agent is being added? ").strip()

        proj_csv = os.path.join(BASE_DIR, "projected_mlb_team_data.csv")
        fa_csv   = os.path.join(BASE_DIR, "2026_freeagents.csv")

        subprocess.run([
            "python", os.path.join(BASE_DIR, "free_agent_evaluator.py"),
            "--team", team_name,
            "--free_agent", player_name,
            "--proj_csv", proj_csv,
            "--fa_csv", fa_csv
        ])

    elif sub_choice == "c":
        trade_simulator.run_trade_simulator()

# -------------------------------
# Section 3: Pitcher Stuff+ Evaluation
# -------------------------------
def run_pitcher_menu():
    print("\nPitcher Stuff+ Evaluation")
    print("a. Stuff+ Calculator (manual inputs)")
    print("b. Current MLB Player Stuff+ Calculator")
    sub_choice = input("Select option (a–b): ").strip().lower()

    if sub_choice == "a":
        stuff_plus_calculator.run_stuff_plus_calculator()
    elif sub_choice == "b":
        current_player_stuff_plus.run_current_player_stuff_plus()

# -------------------------------
# Section 4: Model Creation
# -------------------------------
def run_model_menu():
    print("\nModel Creation")
    print("a. Stuff+ Model Maker (coming soon)")
    print("b. Run R² analysis with visualizations")
    sub_choice = input("Select option (a–b): ").strip().lower()

    if sub_choice == "a":
        print("Stuff+ Model Maker is not yet implemented. Stay tuned for future updates!")
    elif sub_choice == "b":
        subprocess.run([
            "python", os.path.join(BASE_DIR, "r2_analysis.py"),
            "--finance_csv", os.path.join(BASE_DIR, "mlb_finance_data_1.csv"),
            "--proj_csv", os.path.join(BASE_DIR, "projected_mlb_team_data.csv")
        ])

# -------------------------------
if __name__ == "__main__":
    main()
