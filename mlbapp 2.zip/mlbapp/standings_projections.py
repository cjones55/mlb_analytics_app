#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Projected Standings + Playoff Odds (WAR + Payroll integrated, feature names aligned)
@author: chrisjones
"""
import os
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt


# ALoad data from  Desktop
BASE_DIR = os.path.expanduser("~/Desktop/mlbapp")  # update location if needed

# --- Load historical finance/performance data for training ---
finance_csv = os.path.join(BASE_DIR, "mlb_finance_data_1.csv")  # update location if needed
df = pd.read_csv(finance_csv)

# Normalize WAR column names
df.rename(columns={
    "Team Total WAR": "WAR",
    "Position Players WAR": "P_WAR",
    "Pitching WAR": "PP_WAR"
}, inplace=True)

# Detect win% column
win_col_candidates = [c for c in df.columns if "Win" in c or "Pct" in c]
if not win_col_candidates:
    raise KeyError("No Win% column found. Please check df.columns.")
win_col = win_col_candidates[0]

# Normalize scale if needed
df[win_col] = pd.to_numeric(df[win_col], errors="coerce")
if df[win_col].max() > 1.0:
    df[win_col] = df[win_col] / 100.0

# Exclude 2020 season if present
if "Season" in df.columns:
    df = df[df["Season"] != 2020]

# Payroll to numeric
df["Total_Payroll"] = df["Total_Payroll"].astype(str).str.replace(r"[\$,]", "", regex=True)
df["Total_Payroll"] = pd.to_numeric(df["Total_Payroll"], errors="coerce").fillna(df["Total_Payroll"].median())

# -------------------------------
# Retrain WAR + Payroll → Win% model
# -------------------------------
X_features = df[["WAR", "Total_Payroll"]].copy()
y_win = df[win_col]

combo_model = LinearRegression()
combo_model.fit(X_features, y_win)

# -------------------------------
# Kernel-smoothed playoff probability (2022+ calibration)
# -------------------------------
df_modern = df[df["Season"] >= 2022].copy()
if "playoff_appearance" in df_modern.columns:
    df_modern["playoff_flag"] = df_modern["playoff_appearance"].astype(int)
elif "playoff_apperance" in df_modern.columns:
    df_modern["playoff_flag"] = df_modern["playoff_apperance"].astype(int)
else:
    raise KeyError("No playoff appearance column found.")

win_hist = df_modern[win_col].values
playoff_hist = df_modern["playoff_flag"].values

def kernel_gaussian(u):
    return np.exp(-0.5 * u**2)

def smoothed_playoff_prob(win_pct_query, bandwidth=0.02, floor=0.05):
    weights = kernel_gaussian((win_pct_query - win_hist) / bandwidth)
    num = np.sum(weights * playoff_hist)
    den = np.sum(weights) + 1e-12
    prob = num / den
    return max(prob, floor)

# -------------------------------
# Load projected WAR + Payroll data
# -------------------------------
proj_csv = os.path.join(BASE_DIR, "projected_mlb_team_data.csv")  # update location if needed
proj_df = pd.read_csv(proj_csv)

# Normalize WAR column name if needed
if "WAR" not in proj_df.columns:
    if "projected_war" in proj_df.columns:
        proj_df.rename(columns={"projected_war": "WAR"}, inplace=True)
    elif "Projected WAR" in proj_df.columns:
        proj_df.rename(columns={"Projected WAR": "WAR"}, inplace=True)
    else:
        raise KeyError(f"No WAR column found in {proj_csv}. Columns are: {proj_df.columns.tolist()}")

proj_df["WAR"] = pd.to_numeric(proj_df["WAR"], errors="coerce").fillna(0)

# Normalize payroll column → always call it Total_Payroll to match training
if "projected_salary" in proj_df.columns:
    proj_df["Total_Payroll"] = proj_df["projected_salary"].astype(str).str.replace(r"[\$,]", "", regex=True)
    proj_df["Total_Payroll"] = pd.to_numeric(proj_df["Total_Payroll"], errors="coerce").fillna(df["Total_Payroll"].median())
else:
    proj_df["Total_Payroll"] = df["Total_Payroll"].median()

# Ensure White Sox are present
if "White Sox" not in proj_df["Team"].values:
    proj_df = pd.concat([proj_df, pd.DataFrame([{"Team":"White Sox","WAR":0,"Total_Payroll":df["Total_Payroll"].median()}])], ignore_index=True)

# Division mapping
team_divisions = {
    "Yankees":("AL","East"),"Red Sox":("AL","East"),"Blue Jays":("AL","East"),
    "Rays":("AL","East"),"Orioles":("AL","East"),
    "Guardians":("AL","Central"),"White Sox":("AL","Central"),"Tigers":("AL","Central"),
    "Royals":("AL","Central"),"Twins":("AL","Central"),
    "Astros":("AL","West"),"Mariners":("AL","West"),"Rangers":("AL","West"),
    "Athletics":("AL","West"),"Angels":("AL","West"),
    "Braves":("NL","East"),"Mets":("NL","East"),"Phillies":("NL","East"),
    "Nationals":("NL","East"),"Marlins":("NL","East"),
    "Cubs":("NL","Central"),"Cardinals":("NL","Central"),"Brewers":("NL","Central"),
    "Pirates":("NL","Central"),"Reds":("NL","Central"),
    "Dodgers":("NL","West"),"Giants":("NL","West"),"Padres":("NL","West"),
    "Rockies":("NL","West"),"Diamondbacks":("NL","West"),
}

proj_df["league"] = proj_df["Team"].map(lambda t: team_divisions.get(t,("Unknown","Unknown"))[0])
proj_df["division"] = proj_df["Team"].map(lambda t: team_divisions.get(t,("Unknown","Unknown"))[1])

# -------------------------------
# Predict standings with WAR + Payroll model
# -------------------------------
proj_df["win_pct"] = combo_model.predict(proj_df[["WAR","Total_Payroll"]])
proj_df["wins"] = (proj_df["win_pct"]*162).round().astype(int)
proj_df["losses"] = 162 - proj_df["wins"]
proj_df["playoff_odds"] = proj_df["win_pct"].apply(lambda p: smoothed_playoff_prob(p, bandwidth=0.02, floor=0.05))

# -------------------------------
# Save to CSV in mlbdata folder (for creator use only)
# -------------------------------
output_path = os.path.join(BASE_DIR, "mlb_projected_standings.csv")
proj_df.to_csv(output_path, index=False)

# -------------------------------
# Print grouped standings with league avg $ per WAR
# -------------------------------
for lg in ["AL","NL"]:
    league_df = proj_df[proj_df["league"] == lg]

    # Compute league average payroll per WAR (avoid divide-by-zero)
    valid = league_df[league_df["WAR"] > 0]
    if len(valid) > 0:
        league_avg = (valid["Total_Payroll"].sum() / valid["WAR"].sum()) / 1e6
        league_avg_str = f"League Avg: ${league_avg:.1f}M per WAR"
    else:
        league_avg_str = "League Avg: N/A per WAR"

    print(f"\n{lg} Standings ({league_avg_str}):")

    for div in ["East","Central","West"]:
        block = league_df[league_df["division"] == div].sort_values("wins", ascending=False)
        print(f" {lg} {div}")
        for _, r in block.iterrows():
            # Calculate payroll per WAR (avoid divide-by-zero)
            if r["WAR"] > 0:
                payroll_per_war = r["Total_Payroll"] / r["WAR"]
                payroll_per_war_str = f"${payroll_per_war/1e6:.1f}M per WAR avg"
            else:
                payroll_per_war_str = "N/A per WAR avg"

            print(f" - {r['Team']}: {r['wins']}-{r['losses']} ({r['win_pct']:.3f}), "
                  f"Payroll ${r['Total_Payroll']/1e6:.1f}M, "
                  f"Playoff Odds {r['playoff_odds']*100:.1f}%, "
                  f"{payroll_per_war_str}")


###FIGURE CREATION###

# -------------------------------
# Compute $ per WAR column
# -------------------------------
proj_df = proj_df.copy()
proj_df["$perWAR"] = proj_df.apply(
    lambda r: r["Total_Payroll"]/r["WAR"] if r["WAR"] and r["WAR"] > 0 else None, axis=1
)

# Rename Diamondbacks to DBacks (display name)
proj_df["Team"] = proj_df["Team"].replace({"Diamondbacks": "DBacks"})

# -------------------------------
# Build playoff teams (division winners + wild cards)
# -------------------------------
playoff_teams = {}
for lg in ["AL","NL"]:
    league_df = proj_df[proj_df["league"] == lg].copy()

    # Division winners
    div_winner_idx = league_df.groupby("division")["wins"].idxmax()
    div_winners = league_df.loc[div_winner_idx]

    # Wild cards
    remaining = league_df.drop(div_winner_idx)
    wild_cards = remaining.nlargest(3, "wins")

    # Combine
    bracket_df = pd.concat([div_winners, wild_cards]).sort_values("wins", ascending=False)
    bracket_df["seed"] = range(1, len(bracket_df)+1)
    playoff_teams[lg] = bracket_df

# Collect playoff team indices
playoff_ids = pd.concat([playoff_teams["AL"], playoff_teams["NL"]]).index
contenders = proj_df.loc[playoff_ids]

# -------------------------------
# Identify efficient/inefficient teams
# -------------------------------
# Efficient = top 5 lowest $ per WAR among contenders
valid_contenders = contenders.dropna(subset=["$perWAR"])
top5_efficient = valid_contenders.nsmallest(5, "$perWAR")["Team"].values

# Inefficient = bottom 5 highest $ per WAR among all teams
valid_all = proj_df.dropna(subset=["$perWAR"])
bottom5_inefficient = valid_all.nlargest(5, "$perWAR")["Team"].values

# -------------------------------
# Compute overall league average $ per WAR
# -------------------------------
valid_league = proj_df[(proj_df["WAR"] > 0)]
league_avg = (valid_league["Total_Payroll"].sum() / valid_league["WAR"].sum()) / 1e6 if len(valid_league) else None
league_avg_str = f"League Avg: ${league_avg:.1f}M per WAR" if league_avg is not None else "League Avg: N/A per WAR"

# -------------------------------
# Format values for display
# -------------------------------
df = proj_df.copy()
df["Total_Payroll"] = (df["Total_Payroll"]/1e6).round(1).astype(str) + "M"
df["$perWAR"] = df["$perWAR"].apply(lambda x: f"${x/1e6:.1f}M" if pd.notnull(x) else "N/A")
df["win_pct"] = df["win_pct"].round(3)
df["playoff_odds"] = (df["playoff_odds"]*100).round(1).astype(str) + "%"

# Sort by league/division/wins
df = df.sort_values(["league","division","wins"], ascending=[True,True,False])

# Division list split by league (AL left, NL right)
al_divisions = [("AL","East"), ("AL","Central"), ("AL","West")]
nl_divisions = [("NL","East"), ("NL","Central"), ("NL","West")]

# Team colors dictionary (accent colors for team name column)
team_colors = {
    "Yankees": "#4C6EDB",   # brighter navy
    "Red Sox": "#FF4C4C",   # vivid red
    "Blue Jays": "#3FA9F5", # electric blue
    "Rays": "#4DA6FF",      # lighter sky blue
    "Orioles": "#FF6600",   # bold orange
    "Guardians": "#E60026", # strong crimson
    "White Sox": "#C0C0C0", # silver instead of pure white
    "Tigers": "#FF7A3D",    # brighter orange
    "Royals": "#33CFFF",    # cyan-blue
    "Twins": "#FF3344",     # punchy red
    "Astros": "#3366FF",    # royal blue
    "Mariners": "#3D8EB9",  # teal-blue
    "Rangers": "#4C6EDB",   # brighter navy
    "Athletics": "#00A86B", # emerald green
    "Angels": "#FF1A40",    # vivid red
    "Braves": "#FF3355",    # strong red
    "Mets": "#FF7A1A",      # bright orange
    "Phillies": "#FF3344",  # punchy red
    "Nationals": "#E60026", # crimson
    "Marlins": "#33CFFF",   # cyan-blue
    "Cubs": "#3366FF",      # royal blue
    "Cardinals": "#FF3344", # punchy red
    "Brewers": "#FFD633",   # golden yellow
    "Pirates": "#FFCC00",   # bold gold
    "Reds": "#FF3344",      # punchy red
    "Dodgers": "#4DA6FF",   # lighter sky blue
    "Giants": "#FF7A3D",    # bright orange
    "Padres": "#FFD633",    # golden yellow
    "Rockies": "#9933FF",   # vivid purple
    "DBacks": "#E60026"     # crimson red
}

# Columns to show
cols = ["Team", "WAR", "Total_Payroll", "$perWAR", "win_pct", "wins", "losses", "playoff_odds"]

# -------------------------------
# Helper to draw one division table with proper highlighting
# -------------------------------
def draw_division_table(ax, block, title):
    ax.axis("off")
    block = block[cols]

    table = ax.table(
        cellText=block.values,
        colLabels=block.columns,
        cellLoc="center",
        loc="center"
    )
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1.2, 1.2)

    # Header styling
    for (row, col), cell in table.get_celld().items():
        if row == 0:
            cell.set_facecolor("black")
            cell.set_text_props(color="white", weight="bold")

    # Data rows
    n_rows = len(block)
    n_cols = len(cols)
    for r in range(1, n_rows + 1):
        team_name = block.iloc[r - 1]["Team"]

        # Determine row highlight color
        highlight = None
        if team_name in top5_efficient:
            highlight = "#90EE90"  # light green
        elif team_name in bottom5_inefficient:
            highlight = "#FFCCCB"  # light red

        for c in range(n_cols):
            cell = table.get_celld()[(r, c)]
            if highlight:
                cell.set_facecolor(highlight)
                if c == 0:  # team name column
                    color = team_colors.get(team_name, "white")
                    cell.set_text_props(weight="bold", color=color)
                else:
                    cell.set_text_props(color="black")
            else:
                cell.set_facecolor("black")
                if c == 0:
                    color = team_colors.get(team_name, "white")
                    cell.set_text_props(weight="bold", color=color)
                else:
                    cell.set_text_props(color="white")

    ax.set_title(title, fontsize=14, pad=10, color="white")

# -------------------------------
# Build grid of tables (AL left, NL right)
# -------------------------------
fig, axes = plt.subplots(3, 2, figsize=(18, 12))

# AL divisions (left column)
for i, (lg, div) in enumerate(al_divisions):
    block = df[(df["league"] == lg) & (df["division"] == div)]
    draw_division_table(axes[i, 0], block, f"{lg} {div}")

# NL divisions (right column)
for i, (lg, div) in enumerate(nl_divisions):
    block = df[(df["league"] == lg) & (df["division"] == div)]
    draw_division_table(axes[i, 1], block, f"{lg} {div}")

# -------------------------------
# Figure styling and legend
# -------------------------------
fig.patch.set_facecolor("black")
plt.suptitle(
    "2026 Projected MLB Standings",
    fontsize=18, y=0.95, color="white", weight="bold"

)

import datetime

# Get today's date
today_str = datetime.date.today().strftime("%B %d, %Y")

# Add small white text in bottom-right
fig.text(
    0.99, 0.01,
    f"Data as of {today_str}",
    fontsize=8, color="white", ha="right", va="bottom"
)


# Legend / key in top-right
fig.text(
    0.79, 0.97,
    "Key:\nLight Green = Top 5 Efficient Contenders\nLight Red = Bottom 5 Inefficient Teams\n" + league_avg_str,
    fontsize=10, color="white", ha="left", va="top",
    bbox=dict(facecolor="black", edgecolor="white", boxstyle="round,pad=0.5")
)

plt.tight_layout()
plt.show()

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

plt.figure(figsize=(12, 6))
ax = plt.gca()

# Black background
ax.set_facecolor("black")
plt.gcf().patch.set_facecolor("black")

# Sort teams by predicted win% (descending) and drop invalid $/WAR
valid_plot = proj_df.dropna(subset=["$perWAR"]).sort_values("win_pct", ascending=False)
x_positions = np.arange(len(valid_plot))

# Normalize team names to full names
team_name_map = {
    "Dodgers": "Los Angeles Dodgers", "Blue Jays": "Toronto Blue Jays", "Braves": "Atlanta Braves",
    "Mets": "New York Mets", "Yankees": "New York Yankees", "Mariners": "Seattle Mariners",
    "Orioles": "Baltimore Orioles", "Phillies": "Philadelphia Phillies", "Red Sox": "Boston Red Sox",
    "Tigers": "Detroit Tigers", "Brewers": "Milwaukee Brewers", "Royals": "Kansas City Royals",
    "Astros": "Houston Astros", "Twins": "Minnesota Twins", "Cubs": "Chicago Cubs",
    "DBacks": "Arizona Diamondbacks", "Padres": "San Diego Padres", "Rays": "Tampa Bay Rays",
    "Rangers": "Texas Rangers", "Athletics": "Oakland Athletics", "Reds": "Cincinnati Reds",
    "Guardians": "Cleveland Guardians", "Giants": "San Francisco Giants", "Cardinals": "St. Louis Cardinals",
    "Pirates": "Pittsburgh Pirates", "Marlins": "Miami Marlins", "Angels": "Los Angeles Angels",
    "Nationals": "Washington Nationals", "White Sox": "Chicago White Sox", "Rockies": "Colorado Rockies"
}

# Market size classification
team_markets = {
    # Small market
    "Tampa Bay Rays": "Small", "Miami Marlins": "Small", "Oakland Athletics": "Small",
    "Chicago White Sox": "Small", "Pittsburgh Pirates": "Small", "Cleveland Guardians": "Small",
    "Baltimore Orioles": "Small", "Kansas City Royals": "Small", "Cincinnati Reds": "Small",
    "Minnesota Twins": "Small", "Detroit Tigers": "Small", "Arizona Diamondbacks": "Small",
    "Washington Nationals": "Small",

    # Medium market
    "Seattle Mariners": "Medium", "Texas Rangers": "Medium", "Philadelphia Phillies": "Medium",
    "New York Mets": "Medium", "Milwaukee Brewers": "Medium", "Toronto Blue Jays": "Medium",
    "Houston Astros": "Medium", "Colorado Rockies": "Medium", "Atlanta Braves": "Medium",
    "San Diego Padres": "Medium", "Los Angeles Angels": "Medium", "San Francisco Giants": "Medium",
    "Boston Red Sox": "Medium", "Chicago Cubs": "Medium", "St. Louis Cardinals": "Medium",
    "New York Yankees": "Medium",

    # Large market
    "Los Angeles Dodgers": "Large"
}

# Market size → color mapping
market_colors = {"Small": "steelblue", "Medium": "orange", "Large": "limegreen"}

# Assign colors based on normalized team names
dot_colors = []
for team in valid_plot["Team"]:
    full_name = team_name_map.get(team, team)
    market = team_markets.get(full_name, "Small")
    dot_colors.append(market_colors[market])

# Scatter plot
plt.scatter(
    x_positions,
    valid_plot["$perWAR"]/1e6,
    color=dot_colors,
    edgecolor="white",
    s=80
)

# Axis labels and title
plt.ylabel("$ per WAR (Millions)", fontsize=12, weight="bold", color="white")
plt.title("Team Efficiency: Payroll per WAR (Sorted by Win%)", fontsize=14, weight="bold", color="white")

# League average line
if league_avg is not None:
    plt.axhline(
        y=league_avg,
        color="red", linestyle="--", linewidth=1.2,
        label=f"League Avg: ${league_avg:.1f}M/WAR"
    )

# X-axis labels
ax.set_xticks(x_positions)
ax.set_xticklabels(valid_plot["Team"], rotation=90, fontsize=9, weight="bold")
for tick, team in zip(ax.get_xticklabels(), valid_plot["Team"]):
    tick.set_color(team_colors.get(team, "white"))

# Y-axis ticks
plt.yticks(color="white")

# Market size legend
legend_elements = [
    Line2D([0], [0], marker='o', color='black', label='Small Market',
           markerfacecolor='steelblue', markersize=8),
    Line2D([0], [0], marker='o', color='black', label='Medium Market',
           markerfacecolor='orange', markersize=8),
    Line2D([0], [0], marker='o', color='black', label='Large Market',
           markerfacecolor='limegreen', markersize=8)
]
ax.legend(handles=legend_elements, facecolor="black", edgecolor="white", labelcolor="white")

plt.tight_layout()
plt.show()


