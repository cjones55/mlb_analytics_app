#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stuff+ Calculator Module
Evaluates pitch quality relative to league average, pitch-type specific.
Author: Chris Jones
"""

from pybaseball import statcast, cache
import pandas as pd

# Enable caching
cache.enable()

# --- Safe Statcast wrapper ---
def safe_statcast(start_dt, end_dt):
    df = statcast(start_dt=start_dt, end_dt=end_dt)
    if df is None or df.empty:
        raise ValueError(f"No Statcast data found between {start_dt} and {end_dt}.")
    if "game_date" not in df.columns:
        raise ValueError(f"Statcast data missing 'game_date' column for {start_dt}–{end_dt}.")
    return df

# --- Compute league averages per pitch type ---
def compute_league_avgs(season=2024):
    print(f"Gathering league-wide data for {season}...")
    try:
        df = safe_statcast(f"{season}-04-01", f"{season}-09-30")
    except ValueError as e:
        # Fallback to previous season if data is missing
        if season > 2024:
            print(f"{e} Retrying with {season-1} data...")
            return compute_league_avgs(season-1)
        else:
            raise

    df['horiz_adj'] = df.apply(
        lambda row: row['pfx_x'] * (-1 if row['p_throws'] == 'L' else 1), axis=1
    )
    df['ivb'] = df['pfx_z'] + 32 * (df['release_extension'] / df['release_speed'])
    df['hvb'] = df['horiz_adj']

    league_avgs = df.groupby('pitch_type').agg({
        'release_speed':'mean',
        'release_spin_rate':'mean',
        'ivb':'mean',
        'hvb':'mean'
    }).to_dict('index')

    return league_avgs

# --- Pitch-type specific weights ---
PITCH_TYPE_WEIGHTS = {
    "FF": {"velocity": 0.19, "spin": 0.09, "ivb": 0.07, "hvb": -0.00},
    "SI": {"velocity": 0.16, "spin": 0.03, "ivb": -0.03, "hvb": 0.12},
    "FC": {"velocity": 0.02, "spin": 0.04, "ivb": -0.03, "hvb": 0.12},
    "SL": {"velocity": 0.05, "spin": 0.08, "ivb": -0.02, "hvb": -0.02},
    "ST": {"velocity": 0.16, "spin": 0.01, "ivb": 0.05, "hvb": -0.01},
    "CU": {"velocity": 0.15, "spin": 0.13, "ivb": 0.07, "hvb": 0.03},
    "KC": {"velocity": 0.25, "spin": 0.00, "ivb": 0.05, "hvb": -0.05},
    "CH": {"velocity": -0.05, "spin": 0.03, "ivb": -0.02, "hvb": -0.05},
    "FS": {"velocity": -0.09, "spin": -0.08, "ivb": -0.02, "hvb": -0.04}
}

def calculate_stuff_plus(pitch_code, velocity, spin, ivb, hvb, league_avgs):
    pitch_code = pitch_code.upper()
    if pitch_code not in PITCH_TYPE_WEIGHTS:
        raise ValueError(f"Unsupported pitch type: {pitch_code}")

    weights = PITCH_TYPE_WEIGHTS[pitch_code]
    avg = league_avgs.get(pitch_code)
    if avg is None:
        raise ValueError(f"No league averages found for pitch type {pitch_code}")

    score = 100
    score += weights["velocity"] * (velocity - avg['release_speed'])
    score += weights["spin"] * (spin - avg['release_spin_rate'])
    score += weights["ivb"] * (ivb - avg['ivb'])
    score += weights["hvb"] * (hvb - avg['hvb'])
    return round(score, 1)

def run_stuff_plus_calculator():
    print("Stuff+ Calculator")
    print("Supported pitch types:", ", ".join(PITCH_TYPE_WEIGHTS.keys()))

    season_input = input("Enter season/year (default 2024): ").strip()
    season = int(season_input) if season_input else 2024

    try:
        league_avgs = compute_league_avgs(season)
    except ValueError as e:
        print("Data error:", e)
        return

    try:
        pitch_code = input("Enter pitch code (e.g. FF, SI, SL): ").strip().upper()
        velocity = float(input("Enter pitch velocity (mph): "))
        spin = float(input("Enter spin rate (rpm): "))
        ivb = float(input("Enter induced vertical break (inches): "))
        hvb = float(input("Enter horizontal break (inches): "))
    except Exception:
        print("Invalid input. Using defaults (FF league averages).")
        pitch_code = "FF"
        avg = league_avgs[pitch_code]
        velocity, spin, ivb, hvb = avg['release_speed'], avg['release_spin_rate'], avg['ivb'], avg['hvb']

    try:
        stuff_plus = calculate_stuff_plus(pitch_code, velocity, spin, ivb, hvb, league_avgs)
        print(f"\nCalculated Stuff+ for {pitch_code}: {stuff_plus} (100 = league average)")
    except ValueError as e:
        print(e)

if __name__ == "__main__":
    run_stuff_plus_calculator()

