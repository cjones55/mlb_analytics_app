#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  5 12:15:07 2025

@author: chrisjones
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Enhanced R² Analysis + Clustering + Regression Line + Salary Box Plots
Runs automatically in Spyder or CLI
- Robust handling of 'playoff_appearance' vs legacy 'playoff_apperance'
- Safe numeric coercion and missing-value imputation
@author: chrisjones
"""
import os
import argparse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import r2_score, roc_auc_score
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.cluster import KMeans


def _coerce_numeric(series):
    """Coerce to numeric, stripping $ and commas if present."""
    s = series.astype(str).str.strip()
    s = s.str.replace(r"[\$,]", "", regex=True)
    return pd.to_numeric(s, errors="coerce")


def _get_playoff_flag(df):
    """
    Return a clean binary playoff flag as int (0/1).
    Supports either 'playoff_appearance' (correct) or 'playoff_apperance' (legacy typo).
    Also coerces strings like '', 'yes', 'no', 'True', 'False', '1', '0'.
    """
    col = None
    if "playoff_appearance" in df.columns:
        col = "playoff_appearance"
    elif "playoff_apperance" in df.columns:
        col = "playoff_apperance"
    else:
        raise ValueError("Missing playoff appearance column (expected 'playoff_appearance').")

    s = df[col].astype(str).str.strip().str.lower()

    # Map common string forms to 0/1
    mapping = {
        "": np.nan, "nan": np.nan, "none": np.nan, "null": np.nan,
        "0": 0, "no": 0, "false": 0, "f": 0,
        "1": 1, "yes": 1, "true": 1, "t": 1
    }
    s = s.map(mapping).astype("float")  # float to allow NaN
    # If there are NaNs, fill them conservatively with 0 (not playoff)
    s = s.fillna(0.0)
    return s.astype(int)


def run_r2_analysis(finance_csv, proj_csv):
    # -------------------------------
    # Load and clean historical finance data
    # -------------------------------
    df = pd.read_csv(finance_csv)

    # Normalize column names expected by the analysis
    df.rename(
        columns={
            "Team Total WAR": "WAR",
            "Position Players WAR": "P_WAR",
            "Pitching WAR": "PP_WAR",
        },
        inplace=True,
    )

    # Numeric coercions
    if "Total_Payroll" in df.columns:
        df["Total_Payroll"] = _coerce_numeric(df["Total_Payroll"])
    else:
        raise ValueError("Missing 'Total_Payroll' column.")

    if "Win_%" in df.columns:
        # Coerce Win_% to numeric; if expressed as percentage like '55.3', we keep as is (later /100 if needed)
        df["Win_%"] = _coerce_numeric(df["Win_%"])
    else:
        raise ValueError("Missing 'Win_%' column.")

    for c in ["WAR", "P_WAR", "PP_WAR"]:
        if c in df.columns:
            df[c] = _coerce_numeric(df[c])
        else:
            raise ValueError(f"Missing '{c}' column.")

    # Build playoff flag robustly (handles both spellings and string values)
    df["playoff_flag"] = _get_playoff_flag(df)

    # Exclude 2020 (shortened season) if Season exists
    if "Season" in df.columns:
        df = df[df["Season"] != 2020]

    # Filter span (adjust if needed)
    df_span = df[(df["Season"] >= 2015) & (df["Season"] <= 2025)].copy()

    # Targets
    y_win = df_span["Win_%"] / 100.0 if df_span["Win_%"].max() > 1 else df_span["Win_%"]
    y_playoff = df_span["playoff_flag"].astype(int)

    # -------------------------------
    # Multi-feature regression
    # -------------------------------
    X = df_span[["WAR", "Total_Payroll", "P_WAR", "PP_WAR"]].copy()

    # Impute any remaining NaNs in features with median (keeps analysis running on sparse data)
    X = X.apply(lambda col: col.fillna(col.median()))

    X_train, X_test, y_train, y_test = train_test_split(X, y_win, test_size=0.2, random_state=42)

    linreg = LinearRegression().fit(X_train, y_train)
    rfreg = RandomForestRegressor(n_estimators=300, random_state=42).fit(X_train, y_train)

    print("\n--- Regression Results ---")
    print(
        f"Linear Regression: Train R²={r2_score(y_train, linreg.predict(X_train)):.3f}, "
        f"Test R²={r2_score(y_test, linreg.predict(X_test)):.3f}"
    )
    print(
        f"Random Forest: Train R²={r2_score(y_train, rfreg.predict(X_train)):.3f}, "
        f"Test R²={r2_score(y_test, rfreg.predict(X_test)):.3f}"
    )
    print(
        "Random Forest Feature Importances:",
        {col: round(val, 3) for col, val in zip(X.columns, rfreg.feature_importances_)},
    )

    # -------------------------------
    # Classification: Playoff flag
    # -------------------------------
    X_train_c, X_test_c, y_train_c, y_test_c = train_test_split(
        X, y_playoff, test_size=0.2, random_state=42
    )
    logreg = LogisticRegression(max_iter=1000, class_weight="balanced").fit(X_train_c, y_train_c)
    rfclf = RandomForestClassifier(
        n_estimators=300, random_state=42, class_weight="balanced"
    ).fit(X_train_c, y_train_c)

    print("\n--- Classification Results ---")
    print(f"Logistic ROC-AUC={roc_auc_score(y_test_c, logreg.predict_proba(X_test_c)[:, 1]):.3f}")
    print(f"Random Forest ROC-AUC={roc_auc_score(y_test_c, rfclf.predict_proba(X_test_c)[:, 1]):.3f}")
    print("Random Forest Accuracy:", round(rfclf.score(X_test_c, y_test_c), 3))

    # -------------------------------
    # Cross-validation
    # -------------------------------
    scores = cross_val_score(LinearRegression(), X, y_win, cv=5, scoring="r2")
    print("\nCross-validated R² scores:", [round(s, 3) for s in scores])
    print("Mean R²:", round(scores.mean(), 3))

    # -------------------------------
    # Correlation heatmap
    # -------------------------------
    corr = df_span[["WAR", "P_WAR", "PP_WAR", "Total_Payroll", "Win_%", "playoff_flag"]].corr()
    plt.figure(figsize=(8, 6))
    sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation Matrix")
    plt.tight_layout()
    plt.show()

    # -------------------------------
    # WAR vs Win% clustering + regression line
    # -------------------------------
    war_win = df_span[["WAR"]].copy()
    war_win["Win%"] = y_win

    # KMeans clustering
    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10).fit(war_win.dropna())
    # Align labels back to df_span (handle potential NaNs)
    valid_idx = war_win.dropna().index
    cluster_labels = pd.Series(index=df_span.index, dtype="float")
    cluster_labels.loc[valid_idx] = kmeans.labels_
    df_span["cluster"] = cluster_labels.fillna(-1).astype(int)  # -1 for missing

    centroids = kmeans.cluster_centers_

    # Linear regression line on WAR -> Win%
    lin_model = LinearRegression().fit(df_span[["WAR"]].fillna(df_span["WAR"].median()), y_win)
    r2_war = r2_score(y_win, lin_model.predict(df_span[["WAR"]].fillna(df_span["WAR"].median())))
    war_range = pd.DataFrame(
        np.linspace(df_span["WAR"].min(), df_span["WAR"].max(), 500), columns=["WAR"]
    )
    reg_line = lin_model.predict(war_range)

    plt.figure(figsize=(10, 6))
    palette = sns.color_palette("Set2", 4)
    sns.scatterplot(
        data=df_span, x="WAR", y="Win_%", hue="cluster", palette=palette, s=60, alpha=0.7, legend=False
    )

    # Centroid markers with mean labels
    for i, (x_c, y_c) in enumerate(centroids):
        plt.scatter(
            x_c, y_c, color=palette[i], edgecolor="black", s=200, marker="X",
            label=f"Mean WAR={x_c:.1f}, Win%={y_c:.3f}"
        )

    # Regression line
    plt.plot(
        war_range["WAR"], reg_line, color="black", linestyle="--", linewidth=2,
        label=f"Linear Regression (R²={r2_war:.3f})"
    )

    plt.title("WAR vs Win% Clusters + Regression (2015–2025)")
    plt.xlabel("Team WAR")
    plt.ylabel("Win%")
    plt.legend(loc="lower right", fontsize=10)
    plt.grid(True, linestyle="--", alpha=0.6)
    plt.tight_layout()
    plt.show()

    # -------------------------------
    # Salary box plots by playoff status (robust)
    # -------------------------------
    df_box = df_span.copy()
    df_box["Playoff Status"] = df_box["playoff_flag"].map({0: "No Playoff", 1: "Playoff"})

    # Coerce payroll to numeric and impute missing values with median to ensure both categories plot
    df_box["Total_Payroll"] = pd.to_numeric(df_box["Total_Payroll"], errors="coerce")
    if df_box["Total_Payroll"].isna().any():
        median_payroll = df_box["Total_Payroll"].median()
        df_box["Total_Payroll"] = df_box["Total_Payroll"].fillna(median_payroll)

    # Confirm category presence
    cat_counts = df_box["Playoff Status"].value_counts()
    print("\nPlayoff status counts:", dict(cat_counts))

    # Order and palette
    order = ["No Playoff", "Playoff"]
    palette_box = {"No Playoff": "gray", "Playoff": "red"}

    # Filter to present categories (avoid empty sequence errors)
    present = [c for c in order if c in cat_counts.index]
    df_box = df_box[df_box["Playoff Status"].isin(present)]

    if len(df_box) == 0:
        print("No valid salary data to plot after cleaning.")
    else:
        plt.figure(figsize=(8, 6))
        sns.boxplot(data=df_box, x="Playoff Status", y="Total_Payroll", order=present, palette=palette_box)
        plt.title("Team Salary Distribution by Playoff Status")
        plt.ylabel("Total Payroll ($)")
        plt.xlabel("")
        plt.grid(True, linestyle="--", alpha=0.5)

        # Annotate medians
        medians = df_box.groupby("Playoff Status")["Total_Payroll"].median()
        for i, status in enumerate(present):
            if status in medians.index:
                plt.text(i, medians[status], f"${medians[status]/1e6:.1f}M",
                         ha="center", va="bottom", fontsize=10, color="black")

        plt.tight_layout()
        plt.show()

    # Histogram for each cluster separately
    for status in present:
        subset = df_box[df_box["Playoff Status"] == status]
    plt.figure(figsize=(8, 6))
    sns.histplot(subset["Total_Payroll"], bins=10, kde=True, color=palette_box[status])
    plt.title(f"Payroll Distribution: {status}")
    plt.xlabel("Total Payroll ($)")
    plt.ylabel("Count")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.show()

# KDE plots separately
    for status in present:
        subset = df_box[df_box["Playoff Status"] == status]
    plt.figure(figsize=(8, 6))
    sns.kdeplot(subset["Total_Payroll"], fill=True, color=palette_box[status])
    plt.title(f"Payroll Density Curve: {status}")
    plt.xlabel("Total Payroll ($)")
    plt.ylabel("Density")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.show()
    
    
    # -------------------------------
    # Histogram for each playoff status separately
    # -------------------------------
    for status in present:
        subset = df_box[df_box["Playoff Status"] == status]
        plt.figure(figsize=(8, 6))
        sns.histplot(subset["Total_Payroll"], bins=10, kde=True, color=palette_box[status])
        plt.title(f"Payroll Distribution: {status}")
        plt.xlabel("Total Payroll ($)")
        plt.ylabel("Count")
        plt.grid(True, linestyle="--", alpha=0.5)
        plt.tight_layout()
        plt.show()

    # -------------------------------
    # KDE plots separately
    # -------------------------------
    for status in present:
        subset = df_box[df_box["Playoff Status"] == status]
        plt.figure(figsize=(8, 6))
        sns.kdeplot(subset["Total_Payroll"], fill=True, color=palette_box[status])
        plt.title(f"Payroll Density Curve: {status}")
        plt.xlabel("Total Payroll ($)")
        plt.ylabel("Density")
        plt.grid(True, linestyle="--", alpha=0.5)
        plt.tight_layout()
        plt.show()

    # -------------------------------
    # Cluster diagnostics: size, summary, distribution
    # -------------------------------
    cluster_map = {0: "Mid WAR", 1: "High WAR", 2: "Low WAR"}
    df_span["Cluster"] = df_span["cluster"].map(cluster_map)

    cluster_counts = df_span["Cluster"].value_counts()
    print("\nCluster sizes:")
    for cluster, count in cluster_counts.items():
        print(f"  {cluster}: {count} teams")

    print("\nFive-number summaries:")
    for cluster in cluster_counts.index:
        subset = df_span[df_span["Cluster"] == cluster]
        print(f"\n{cluster}:")
        for col in ["WAR", "Win_%"]:
            desc = subset[col].describe()
            print(f"  {col}: min={desc['min']:.2f}, Q1={desc['25%']:.2f}, "
                  f"median={desc['50%']:.2f}, Q3={desc['75%']:.2f}, max={desc['max']:.2f}")

    for col in ["WAR", "Win_%"]:
        plt.figure(figsize=(8, 6))
        for cluster in cluster_counts.index:
            subset = df_span[df_span["Cluster"] == cluster]
            sns.kdeplot(subset[col], label=cluster, fill=True, alpha=0.5)
        plt.title(f"{col} Distribution by Cluster")
        plt.xlabel(col)
        plt.ylabel("Density")
        plt.legend(title="Cluster")
        plt.grid(True, linestyle="--", alpha=0.5)
        plt.tight_layout()
        plt.show()
        
        # Efficiency metrics
        df_span["Payroll_M"] = df_span["Total_Payroll"] / 1e6
        df_span["WAR_per_M"] = df_span["WAR"] / df_span["Payroll_M"]
        df_span["Win_per_M"] = df_span["Win_%"] / df_span["Payroll_M"]

# -------------------------------
# Efficiency analysis: Top 75 teams + finishing positions
# -------------------------------

    import statsmodels.api as sm

# Create Payroll_M and residuals
    df_span["Payroll_M"] = df_span["Total_Payroll"] / 1e6
    X = sm.add_constant(df_span["Payroll_M"])
    y = df_span["WAR"]
    model = sm.OLS(y, X).fit()
    df_span["eff_residual"] = model.resid

# Expand to top 75 efficient teams
    top_eff = df_span.sort_values("eff_residual", ascending=False).head(75).copy()

# Auto-generate finishing status from actual columns
    def get_finish(row):
        if str(row.get("world_series_winner")).strip().lower() in ["1", "true", "yes"]:
            return "Won WS"
        elif str(row.get("world_series")).strip().lower() in ["1", "true", "yes"]:
            return "Lost WS"
        elif str(row.get("playoff_apperance")).strip().lower() in ["1", "true", "yes"]:
            return "Made Playoffs"
        else:
            return "Missed Playoffs"

    top_eff["Finish"] = top_eff.apply(get_finish, axis=1)


# Save to CSV
    top_eff[["Team", "Season", "WAR", "Payroll_M", "eff_residual", "Finish"]].to_csv(
    "top75_efficiency.csv", index=False
)
    print("Saved results to top75_efficiency.csv")




# -------------------------------
# Entry point: supports Spyder and CLI
# -------------------------------
def _resolve_paths(args):
    default_finance = os.path.expanduser("~/Desktop/mlbapp/mlb_finance_data_1.csv")
    default_proj = os.path.expanduser("~/Desktop/mlbapp/projected_mlb_team_data.csv")
    finance_path = args.finance_csv if args.finance_csv else default_finance
    proj_path = args.proj_csv if args.proj_csv else default_proj
    return finance_path, proj_path


if __name__ == "__main__" or "__file__" in globals():
    parser = argparse.ArgumentParser(
        description="Enhanced R² analysis with clustering, regression line, and salary box plots"
    )
    parser.add_argument("--finance_csv", help="Path to finance CSV")
    parser.add_argument("--proj_csv", help="Path to projected team CSV")
    args, _ = parser.parse_known_args()

    finance_path, proj_path = _resolve_paths(args)
    run_r2_analysis(finance_path, proj_path)
